package com.shadowfix.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.shadowfix.app.data.datastore.SettingsDataStore
import com.shadowfix.app.data.repository.ProfileRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ShadowFixAccessibilityService
 *
 * ── Purpose ──────────────────────────────────────────────────────────────────
 * Observes [AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED] events so that
 * ShadowFix can automatically switch enhancement profiles when the user
 * switches between apps (per-app profile mapping).
 *
 * ── Privacy & Security guarantee ─────────────────────────────────────────────
 * This service ONLY listens for WINDOW_STATE_CHANGED events, which expose
 * the package name and class name of the active window — nothing more.
 * It does NOT:
 *  • Read screen content, passwords, or text fields.
 *  • Perform any gesture or automated interaction.
 *  • Collect, transmit, or store any user data.
 *
 * The accessibility_service_config.xml restricts event types and explicitly
 * disables canRetrieveWindowContent to enforce these guarantees at the OS level.
 *
 * ── Android restriction note ─────────────────────────────────────────────────
 * Accessibility Services require explicit user opt-in in Settings →
 * Accessibility.  The app cannot grant this permission programmatically;
 * it can only deep-link to the Accessibility Settings page and explain why
 * the permission is needed.
 */
@AndroidEntryPoint
class ShadowFixAccessibilityService : AccessibilityService() {

    @Inject lateinit var settingsDataStore: SettingsDataStore
    @Inject lateinit var profileRepository: ProfileRepository

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /** Package name of the last observed foreground app. */
    private var lastForegroundPackage: String? = null

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Programmatically set event types as a safety net alongside XML config.
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 200L
            flags = 0   // canRetrieveWindowContent deliberately NOT set
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onInterrupt() {
        // No ongoing gestures or interactions to interrupt.
    }

    // ── Event handling ────────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // Ignore self-events (ShadowFix UI) and system UI packages.
        if (pkg == packageName || pkg.startsWith("com.android.systemui")) return

        // Only act when the package actually changes (debounce same-app events).
        if (pkg == lastForegroundPackage) return
        lastForegroundPackage = pkg

        handleForegroundPackageChange(pkg)
    }

    // ── Per-app profile switching ─────────────────────────────────────────────

    /**
     * Looks up whether any profile is mapped to [packageName] and, if so,
     * applies it.  All I/O and coroutine work is performed on [Dispatchers.IO]
     * to avoid blocking the accessibility event thread.
     */
    private fun handleForegroundPackageChange(packageName: String) {
        serviceScope.launch {
            // Check if per-app profiles are enabled by the user.
            val perAppEnabled = settingsDataStore.perAppProfilesEnabled.first()
            if (!perAppEnabled) return@launch

            // Find the first profile that lists this package.
            val matchingProfile = profileRepository.profiles.first()
                .firstOrNull { profile -> packageName in profile.appPackages }
                ?: return@launch  // No mapping; leave current profile unchanged.

            // Activate the matching profile.
            settingsDataStore.setActiveProfileId(matchingProfile.id)
            settingsDataStore.setNearBlack(matchingProfile.nearBlack)
            settingsDataStore.setGamma(matchingProfile.gamma)
            settingsDataStore.setShadowBoost(matchingProfile.shadowBoost)
            settingsDataStore.setContrast(matchingProfile.contrast)
            settingsDataStore.setBlackLevel(matchingProfile.blackLevel)
            settingsDataStore.setStrength(matchingProfile.strength)

            // Broadcast intent so the OverlayService immediately re-reads DataStore.
            sendBroadcast(
                Intent(ACTION_PROFILE_CHANGED).apply {
                    `package` = this@ShadowFixAccessibilityService.packageName
                    putExtra(EXTRA_PROFILE_ID, matchingProfile.id)
                }
            )
        }
    }

    companion object {
        const val ACTION_PROFILE_CHANGED = "com.shadowfix.app.PROFILE_CHANGED"
        const val EXTRA_PROFILE_ID = "profile_id"
    }
}
