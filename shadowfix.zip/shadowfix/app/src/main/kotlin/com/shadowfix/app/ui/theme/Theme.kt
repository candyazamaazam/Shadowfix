package com.shadowfix.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import com.shadowfix.app.data.datastore.SettingsDataStore

// ── Dark colour scheme ────────────────────────────────────────────────────────

private val DarkColorScheme = darkColorScheme(
    primary          = ShadowRed,
    onPrimary        = ShadowWhite,
    primaryContainer = ShadowRedDark,
    onPrimaryContainer = ShadowOnDark,
    secondary        = ShadowRedLight,
    onSecondary      = ShadowBlack,
    background       = ShadowBlack,
    onBackground     = ShadowOnDark,
    surface          = ShadowSurface,
    onSurface        = ShadowOnDark,
    surfaceVariant   = ShadowSurface2,
    onSurfaceVariant = ShadowOnDark2,
    outline          = ShadowSurface3,
    error            = ShadowRedLight
)

// ── Light colour scheme ───────────────────────────────────────────────────────

private val LightColorScheme = lightColorScheme(
    primary          = ShadowRedDark,
    onPrimary        = ShadowWhite,
    primaryContainer = ShadowRedLight,
    onPrimaryContainer = ShadowOnLight,
    secondary        = ShadowRed,
    onSecondary      = ShadowWhite,
    background       = ShadowWhite,
    onBackground     = ShadowOnLight,
    surface          = ShadowLight,
    onSurface        = ShadowOnLight,
    surfaceVariant   = ShadowLightSurf,
    onSurfaceVariant = ShadowOnLight2,
    outline          = ShadowTrackLight,
    error            = ShadowRed
)

/**
 * Root Compose theme for ShadowFix.
 *
 * Reads [SettingsDataStore] to react to:
 *  - [SettingsDataStore.dynamicColors] — uses Android 12+ Material You colours.
 *  - [SettingsDataStore.darkMode]      — forces dark/light regardless of system.
 *
 * Falls back gracefully on Android < 12 (dynamic colours not available).
 */
@Composable
fun ShadowFixTheme(
    settingsDataStore: SettingsDataStore? = null,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()

    // Collect settings; if no DataStore is injected (previews) use system defaults.
    val dynamicColors by (settingsDataStore?.dynamicColors
        ?: kotlinx.coroutines.flow.flowOf(false))
        .collectAsState(initial = false)
    val darkMode by (settingsDataStore?.darkMode
        ?: kotlinx.coroutines.flow.flowOf(systemDark))
        .collectAsState(initial = systemDark)

    val colorScheme = when {
        dynamicColors && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkMode) dynamicDarkColorScheme(context)
            else          dynamicLightColorScheme(context)
        }
        darkMode -> DarkColorScheme
        else     -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography  = ShadowFixTypography,
        content     = content
    )
}
