package com.shadowfix.app.viewmodel

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowfix.app.data.datastore.SettingsDataStore
import com.shadowfix.app.data.model.Profile
import com.shadowfix.app.data.repository.ProfileRepository
import com.shadowfix.app.service.OverlayService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * HomeViewModel — drives the Home screen.
 *
 * Exposes a single [UiState] [StateFlow] that the Compose screen observes.
 * All mutations go through dedicated update functions that write to [SettingsDataStore]
 * and start/stop [OverlayService] as needed.
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsDataStore: SettingsDataStore,
    private val profileRepository: ProfileRepository
) : ViewModel() {

    // ── Initialise repository on first use ────────────────────────────────────

    init {
        viewModelScope.launch {
            profileRepository.init()
        }
    }

    // ── UI State ──────────────────────────────────────────────────────────────

    /**
     * Combined UI state built from eight independent DataStore flows.
     *
     * kotlinx.coroutines typed overloads only go up to 5 flows, so we use
     * two nested [combine] calls (5 + 3) to stay fully type-safe without casts.
     */
    val uiState: StateFlow<HomeUiState> = combine(
        combine(
            settingsDataStore.masterEnabled,
            settingsDataStore.activeProfileId,
            settingsDataStore.nearBlack,
            settingsDataStore.gamma,
            settingsDataStore.shadowBoost
        ) { enabled, profileId, nearBlack, gamma, shadowBoost ->
            PartialState(enabled, profileId, nearBlack, gamma, shadowBoost)
        },
        settingsDataStore.contrast,
        settingsDataStore.blackLevel,
        settingsDataStore.strength
    ) { partial, contrast, blackLevel, strength ->
        HomeUiState(
            masterEnabled   = partial.masterEnabled,
            activeProfileId = partial.activeProfileId,
            nearBlack       = partial.nearBlack,
            gamma           = partial.gamma,
            shadowBoost     = partial.shadowBoost,
            contrast        = contrast,
            blackLevel      = blackLevel,
            strength        = strength
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState()
    )

    val profiles: StateFlow<List<Profile>> = profileRepository.profiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // ── Actions ───────────────────────────────────────────────────────────────

    fun setMasterEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsDataStore.setMasterEnabled(enabled)
            if (enabled) startOverlayService() else stopOverlayService()
        }
    }

    fun setActiveProfile(profile: Profile) {
        viewModelScope.launch {
            settingsDataStore.setActiveProfileId(profile.id)
            settingsDataStore.setNearBlack(profile.nearBlack)
            settingsDataStore.setGamma(profile.gamma)
            settingsDataStore.setShadowBoost(profile.shadowBoost)
            settingsDataStore.setContrast(profile.contrast)
            settingsDataStore.setBlackLevel(profile.blackLevel)
            settingsDataStore.setStrength(profile.strength)
        }
    }

    fun setNearBlack(value: Float)   { viewModelScope.launch { settingsDataStore.setNearBlack(value) } }
    fun setGamma(value: Float)       { viewModelScope.launch { settingsDataStore.setGamma(value) } }
    fun setShadowBoost(value: Float) { viewModelScope.launch { settingsDataStore.setShadowBoost(value) } }
    fun setContrast(value: Float)    { viewModelScope.launch { settingsDataStore.setContrast(value) } }
    fun setBlackLevel(value: Float)  { viewModelScope.launch { settingsDataStore.setBlackLevel(value) } }
    fun setStrength(value: Float)    { viewModelScope.launch { settingsDataStore.setStrength(value) } }

    fun resetToDefaults() {
        viewModelScope.launch {
            settingsDataStore.setNearBlack(0.25f)
            settingsDataStore.setGamma(0.30f)
            settingsDataStore.setShadowBoost(0.20f)
            settingsDataStore.setContrast(0.50f)
            settingsDataStore.setBlackLevel(0.04f)
            settingsDataStore.setStrength(0.60f)
        }
    }

    fun saveCurrentAsProfile(name: String) {
        viewModelScope.launch {
            val state = uiState.value
            val profile = profileRepository.createNew(name).copy(
                nearBlack   = state.nearBlack,
                gamma       = state.gamma,
                shadowBoost = state.shadowBoost,
                contrast    = state.contrast,
                blackLevel  = state.blackLevel,
                strength    = state.strength
            )
            profileRepository.save(profile)
        }
    }

    /** Opens the system Overlay Permission Settings for SYSTEM_ALERT_WINDOW. */
    fun openOverlayPermissionSettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:${context.packageName}")
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(intent)
    }

    /** Checks whether the SYSTEM_ALERT_WINDOW permission has been granted. */
    fun hasOverlayPermission(): Boolean =
        Settings.canDrawOverlays(context)

    // ── Service control ───────────────────────────────────────────────────────

    private fun startOverlayService() {
        val intent = Intent(context, OverlayService::class.java)
        context.startForegroundService(intent)
    }

    private fun stopOverlayService() {
        val intent = Intent(context, OverlayService::class.java).apply {
            action = OverlayService.ACTION_STOP
        }
        context.startService(intent)
    }
}

// ── UI State model ─────────────────────────────────────────────────────────────

/**
 * Immutable snapshot of the home screen's state.
 * Default values match the DataStore defaults so the initial frame renders
 * correctly before the first emission.
 */
data class HomeUiState(
    val masterEnabled: Boolean  = false,
    val activeProfileId: String = "preset_movie",
    val nearBlack: Float        = 0.25f,
    val gamma: Float            = 0.30f,
    val shadowBoost: Float      = 0.20f,
    val contrast: Float         = 0.50f,
    val blackLevel: Float       = 0.04f,
    val strength: Float         = 0.60f
)

/** Intermediate holder used by the nested-combine pattern in [HomeViewModel.uiState]. */
private data class PartialState(
    val masterEnabled: Boolean,
    val activeProfileId: String,
    val nearBlack: Float,
    val gamma: Float,
    val shadowBoost: Float
)
