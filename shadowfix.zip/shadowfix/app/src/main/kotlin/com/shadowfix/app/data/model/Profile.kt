package com.shadowfix.app.data.model

/**
 * Represents a complete ShadowFix enhancement profile.
 *
 * All slider values are in the range [0f, 1f] unless noted otherwise.
 * The overlay engine maps these normalised values to the appropriate
 * ColorMatrix coefficients at render time.
 *
 * @property id            Stable unique identifier (UUID string).
 * @property name          Human-readable display name.
 * @property type          Enum indicating the profile category.
 * @property isEnabled     Master toggle for this profile's effects.
 * @property nearBlack     Near-Black Recovery: lifts shadow values that collapse
 *                         to pure black on AMOLED panels. Range 0–1.
 * @property gamma         Gamma correction exponent offset. 0 = neutral (γ=1.0),
 *                         1 = maximum lift (γ=0.5). This brightens mid-tones
 *                         without clipping highlights.
 * @property shadowBoost   Targeted shadow boost: amplifies the lower luminance
 *                         band (0–40% brightness) more aggressively.
 * @property contrast      Overall contrast scale. 0 = low contrast, 0.5 = neutral,
 *                         1 = high contrast.
 * @property blackLevel    Black-point lift. Raises the absolute minimum output
 *                         level so crushed blacks become visible dark grey.
 * @property strength      Master blend strength. 0 = overlay invisible, 1 = full.
 * @property appPackages   List of package names that should auto-activate this
 *                         profile (requires Accessibility Service permission).
 */
data class Profile(
    val id: String,
    val name: String,
    val type: ProfileType,
    val isEnabled: Boolean = true,
    val nearBlack: Float = 0.25f,
    val gamma: Float = 0.3f,
    val shadowBoost: Float = 0.2f,
    val contrast: Float = 0.5f,
    val blackLevel: Float = 0.04f,
    val strength: Float = 0.6f,
    val appPackages: List<String> = emptyList()
)

/**
 * Predefined profile categories.
 *
 * [CUSTOM] is used for user-created profiles that don't fit a preset category.
 */
enum class ProfileType(val displayName: String) {
    MOVIE("Movie"),
    GAMING("Gaming"),
    READING("Reading"),
    NIGHT("Night"),
    OUTDOOR("Outdoor"),
    CUSTOM("Custom")
}

/**
 * Factory that produces the built-in preset profiles.
 * These are the starting defaults; users can override any value.
 */
object ProfileDefaults {

    /**
     * Returns all factory preset profiles.
     * Each preset is tuned for its intended use-case:
     *
     * - MOVIE  : Strong near-black recovery for dark cinema scenes.
     * - GAMING : Balanced boost; slight contrast lift for visibility.
     * - READING: Minimal overlay; gentle gamma only to reduce eye strain.
     * - NIGHT  : Maximum lift to compensate for dim ambient conditions.
     * - OUTDOOR: Reduced effect (outdoor ambient handles visibility naturally).
     */
    fun presets(): List<Profile> = listOf(
        Profile(
            id = "preset_movie",
            name = "Movie",
            type = ProfileType.MOVIE,
            nearBlack = 0.35f,
            gamma = 0.40f,
            shadowBoost = 0.30f,
            contrast = 0.55f,
            blackLevel = 0.06f,
            strength = 0.70f
        ),
        Profile(
            id = "preset_gaming",
            name = "Gaming",
            type = ProfileType.GAMING,
            nearBlack = 0.28f,
            gamma = 0.35f,
            shadowBoost = 0.40f,
            contrast = 0.60f,
            blackLevel = 0.05f,
            strength = 0.65f
        ),
        Profile(
            id = "preset_reading",
            name = "Reading",
            type = ProfileType.READING,
            nearBlack = 0.15f,
            gamma = 0.20f,
            shadowBoost = 0.10f,
            contrast = 0.50f,
            blackLevel = 0.02f,
            strength = 0.40f
        ),
        Profile(
            id = "preset_night",
            name = "Night",
            type = ProfileType.NIGHT,
            nearBlack = 0.45f,
            gamma = 0.50f,
            shadowBoost = 0.50f,
            contrast = 0.45f,
            blackLevel = 0.08f,
            strength = 0.80f
        ),
        Profile(
            id = "preset_outdoor",
            name = "Outdoor",
            type = ProfileType.OUTDOOR,
            nearBlack = 0.10f,
            gamma = 0.15f,
            shadowBoost = 0.10f,
            contrast = 0.65f,
            blackLevel = 0.02f,
            strength = 0.30f
        ),
        Profile(
            id = "preset_custom",
            name = "Custom",
            type = ProfileType.CUSTOM,
            nearBlack = 0.25f,
            gamma = 0.30f,
            shadowBoost = 0.20f,
            contrast = 0.50f,
            blackLevel = 0.04f,
            strength = 0.60f
        )
    )
}
