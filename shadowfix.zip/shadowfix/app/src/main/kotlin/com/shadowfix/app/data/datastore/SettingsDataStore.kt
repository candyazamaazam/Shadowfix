package com.shadowfix.app.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** DataStore extension on Context — one instance per process. */
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "shadowfix_settings")

/**
 * Centralised settings repository backed by Jetpack DataStore (Preferences).
 *
 * All reads are exposed as [Flow]s so the UI layer can react to changes
 * without polling. Writes are suspend functions that update a single key
 * atomically.
 *
 * Injected as a singleton via Hilt.
 */
@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore

    // ── Preference keys ──────────────────────────────────────────────────────

    companion object {
        private val KEY_MASTER_ENABLED = booleanPreferencesKey("master_enabled")
        private val KEY_ACTIVE_PROFILE_ID = stringPreferencesKey("active_profile_id")
        private val KEY_AUTO_START = booleanPreferencesKey("auto_start_on_boot")
        private val KEY_DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        private val KEY_DARK_MODE = booleanPreferencesKey("dark_mode")
        private val KEY_PER_APP_ENABLED = booleanPreferencesKey("per_app_profiles_enabled")

        // Active profile slider values (persisted separately for fast reads)
        private val KEY_NEAR_BLACK = floatPreferencesKey("near_black")
        private val KEY_GAMMA = floatPreferencesKey("gamma")
        private val KEY_SHADOW_BOOST = floatPreferencesKey("shadow_boost")
        private val KEY_CONTRAST = floatPreferencesKey("contrast")
        private val KEY_BLACK_LEVEL = floatPreferencesKey("black_level")
        private val KEY_STRENGTH = floatPreferencesKey("strength")
    }

    // ── Master toggle ────────────────────────────────────────────────────────

    val masterEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_MASTER_ENABLED] ?: false
    }

    suspend fun setMasterEnabled(enabled: Boolean) {
        dataStore.edit { it[KEY_MASTER_ENABLED] = enabled }
    }

    // ── Active profile ───────────────────────────────────────────────────────

    val activeProfileId: Flow<String> = dataStore.data.map { prefs ->
        prefs[KEY_ACTIVE_PROFILE_ID] ?: "preset_movie"
    }

    suspend fun setActiveProfileId(id: String) {
        dataStore.edit { it[KEY_ACTIVE_PROFILE_ID] = id }
    }

    // ── Slider values ────────────────────────────────────────────────────────

    val nearBlack: Flow<Float> = dataStore.data.map { prefs ->
        prefs[KEY_NEAR_BLACK] ?: 0.25f
    }

    suspend fun setNearBlack(value: Float) {
        dataStore.edit { it[KEY_NEAR_BLACK] = value }
    }

    val gamma: Flow<Float> = dataStore.data.map { prefs ->
        prefs[KEY_GAMMA] ?: 0.30f
    }

    suspend fun setGamma(value: Float) {
        dataStore.edit { it[KEY_GAMMA] = value }
    }

    val shadowBoost: Flow<Float> = dataStore.data.map { prefs ->
        prefs[KEY_SHADOW_BOOST] ?: 0.20f
    }

    suspend fun setShadowBoost(value: Float) {
        dataStore.edit { it[KEY_SHADOW_BOOST] = value }
    }

    val contrast: Flow<Float> = dataStore.data.map { prefs ->
        prefs[KEY_CONTRAST] ?: 0.50f
    }

    suspend fun setContrast(value: Float) {
        dataStore.edit { it[KEY_CONTRAST] = value }
    }

    val blackLevel: Flow<Float> = dataStore.data.map { prefs ->
        prefs[KEY_BLACK_LEVEL] ?: 0.04f
    }

    suspend fun setBlackLevel(value: Float) {
        dataStore.edit { it[KEY_BLACK_LEVEL] = value }
    }

    val strength: Flow<Float> = dataStore.data.map { prefs ->
        prefs[KEY_STRENGTH] ?: 0.60f
    }

    suspend fun setStrength(value: Float) {
        dataStore.edit { it[KEY_STRENGTH] = value }
    }

    // ── App settings ─────────────────────────────────────────────────────────

    val autoStartOnBoot: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_AUTO_START] ?: false
    }

    suspend fun setAutoStartOnBoot(enabled: Boolean) {
        dataStore.edit { it[KEY_AUTO_START] = enabled }
    }

    val dynamicColors: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_DYNAMIC_COLORS] ?: true
    }

    suspend fun setDynamicColors(enabled: Boolean) {
        dataStore.edit { it[KEY_DYNAMIC_COLORS] = enabled }
    }

    val darkMode: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_DARK_MODE] ?: true
    }

    suspend fun setDarkMode(enabled: Boolean) {
        dataStore.edit { it[KEY_DARK_MODE] = enabled }
    }

    val perAppProfilesEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_PER_APP_ENABLED] ?: false
    }

    suspend fun setPerAppProfilesEnabled(enabled: Boolean) {
        dataStore.edit { it[KEY_PER_APP_ENABLED] = enabled }
    }
}
