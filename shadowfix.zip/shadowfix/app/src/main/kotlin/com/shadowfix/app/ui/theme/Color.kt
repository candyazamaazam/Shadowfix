package com.shadowfix.app.ui.theme

import androidx.compose.ui.graphics.Color

// ── Nothing-inspired palette ─────────────────────────────────────────────────
// Nothing OS uses a stark monochrome base with a single accent (red/white dot).
// ShadowFix adapts this with deep blacks, bright whites, and a crimson accent.

val ShadowRed        = Color(0xFFFF3B30)   // Nothing-style accent
val ShadowRedDark    = Color(0xFFCC2020)
val ShadowRedLight   = Color(0xFFFF6B60)

// Dark theme surfaces
val ShadowBlack      = Color(0xFF0A0A0A)
val ShadowDark       = Color(0xFF121212)
val ShadowSurface    = Color(0xFF1C1C1C)
val ShadowSurface2   = Color(0xFF242424)
val ShadowSurface3   = Color(0xFF2E2E2E)

// Light theme surfaces
val ShadowWhite      = Color(0xFFFAFAFA)
val ShadowLight      = Color(0xFFF0F0F0)
val ShadowLightSurf  = Color(0xFFE8E8E8)

// Text
val ShadowOnDark     = Color(0xFFEEEEEE)
val ShadowOnDark2    = Color(0xFF9A9A9A)
val ShadowOnLight    = Color(0xFF111111)
val ShadowOnLight2   = Color(0xFF555555)

// Slider track colour
val ShadowTrack      = Color(0xFF3A3A3A)
val ShadowTrackLight = Color(0xFFCDCDCD)
