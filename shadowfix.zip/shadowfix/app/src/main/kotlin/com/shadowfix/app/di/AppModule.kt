package com.shadowfix.app.di

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.shadowfix.app.data.repository.ProfileRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt application-level dependency module.
 *
 * Provides singleton instances of:
 * - [Gson]              — JSON serialiser for profile import/export.
 * - [ProfileRepository] — central profile data store.
 *
 * DataStore and SettingsDataStore are auto-injected via their
 * @Inject constructors and don't require explicit @Provides methods.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /**
     * Provides the Gson instance configured for pretty-printed output
     * so exported profile JSON files are human-readable.
     */
    @Provides
    @Singleton
    fun provideGson(): Gson = GsonBuilder()
        .setPrettyPrinting()
        .serializeNulls()
        .create()

    /**
     * Provides the ProfileRepository singleton.
     * The repository is initialised lazily; call [ProfileRepository.init]
     * once during app startup (triggered by the ViewModel on first collection).
     */
    @Provides
    @Singleton
    fun provideProfileRepository(
        @ApplicationContext context: Context,
        gson: Gson
    ): ProfileRepository = ProfileRepository(context, gson)
}
