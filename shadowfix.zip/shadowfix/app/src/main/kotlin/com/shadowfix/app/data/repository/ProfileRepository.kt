package com.shadowfix.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shadowfix.app.data.model.Profile
import com.shadowfix.app.data.model.ProfileDefaults
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository that owns the in-memory list of profiles and handles
 * persistence to a private JSON file.
 *
 * Profile storage uses a simple JSON file in the app's internal files directory
 * (`files/profiles.json`). This keeps the implementation dependency-free
 * (no Room required) while supporting full CRUD + export/import.
 *
 * Thread safety: all disk I/O is dispatched to [Dispatchers.IO].
 */
@Singleton
class ProfileRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val gson: Gson
) {
    private val profilesFile: File
        get() = File(context.filesDir, "profiles.json")

    private val _profiles = MutableStateFlow<List<Profile>>(emptyList())

    /** Observable list of all profiles. Always contains at least the six presets. */
    val profiles: StateFlow<List<Profile>> = _profiles.asStateFlow()

    // ── Initialisation ───────────────────────────────────────────────────────

    /**
     * Loads profiles from disk (or seeds defaults on first launch).
     * Must be called once during app startup via the Hilt application component.
     */
    suspend fun init() {
        val loaded = loadFromDisk()
        // Merge presets with any user profiles; presets always appear first.
        val presets = ProfileDefaults.presets()
        val userProfiles = loaded.filter { p -> presets.none { it.id == p.id } }
        _profiles.value = presets + userProfiles
    }

    // ── CRUD ─────────────────────────────────────────────────────────────────

    /** Returns the profile with the given [id], or null if not found. */
    fun getById(id: String): Profile? = _profiles.value.find { it.id == id }

    /**
     * Saves (creates or replaces) a profile and persists the full list to disk.
     *
     * If [profile] has an ID that matches an existing profile, it is updated;
     * otherwise it is appended to the list.
     */
    suspend fun save(profile: Profile) {
        val updated = _profiles.value.toMutableList()
        val existingIndex = updated.indexOfFirst { it.id == profile.id }
        if (existingIndex >= 0) {
            updated[existingIndex] = profile
        } else {
            updated.add(profile)
        }
        _profiles.value = updated
        saveToDisk(updated)
    }

    /**
     * Deletes a profile by [id].
     * Built-in preset profiles (IDs starting with "preset_") cannot be deleted.
     *
     * @return true if the profile was removed, false if it was a preset or not found.
     */
    suspend fun delete(id: String): Boolean {
        if (id.startsWith("preset_")) return false
        val updated = _profiles.value.filter { it.id != id }
        if (updated.size == _profiles.value.size) return false
        _profiles.value = updated
        saveToDisk(updated)
        return true
    }

    /** Creates a new custom profile with a fresh UUID and default slider values. */
    fun createNew(name: String): Profile = Profile(
        id = UUID.randomUUID().toString(),
        name = name,
        type = com.shadowfix.app.data.model.ProfileType.CUSTOM
    )

    // ── Export / Import ──────────────────────────────────────────────────────

    /**
     * Serialises the current profile list to a JSON string suitable for
     * writing to an external file chosen by the user via SAF.
     */
    fun exportToJson(): String = gson.toJson(_profiles.value)

    /**
     * Parses a JSON string (from an imported file) and merges the contained
     * profiles into the current list.
     *
     * Preset profiles from the import are silently skipped; custom profiles
     * with duplicate IDs are overwritten.
     *
     * @throws IllegalArgumentException if the JSON is malformed or not a Profile list.
     */
    suspend fun importFromJson(json: String) {
        val type = object : TypeToken<List<Profile>>() {}.type
        val imported: List<Profile> = try {
            gson.fromJson(json, type)
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid profile JSON: ${e.message}", e)
        }
        val nonPresets = imported.filter { !it.id.startsWith("preset_") }
        nonPresets.forEach { save(it) }
    }

    // ── Disk I/O ─────────────────────────────────────────────────────────────

    private suspend fun loadFromDisk(): List<Profile> = withContext(Dispatchers.IO) {
        if (!profilesFile.exists()) return@withContext emptyList()
        try {
            val json = profilesFile.readText()
            val type = object : TypeToken<List<Profile>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: IOException) {
            emptyList()
        }
    }

    private suspend fun saveToDisk(profiles: List<Profile>) = withContext(Dispatchers.IO) {
        try {
            profilesFile.writeText(gson.toJson(profiles))
        } catch (e: IOException) {
            // Non-fatal: in-memory state is already updated; next save will retry.
        }
    }
}
