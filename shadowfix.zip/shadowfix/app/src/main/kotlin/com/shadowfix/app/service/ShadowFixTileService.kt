package com.shadowfix.app.service

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.shadowfix.app.data.datastore.SettingsDataStore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Quick Settings Tile that toggles the ShadowFix overlay on/off.
 *
 * The tile is an "active" tile (declared in the manifest) so the system
 * calls [onStartListening] / [onStopListening] only while the notification
 * shade is open — no unnecessary wake locks.
 *
 * Tapping the tile:
 *  • If the overlay is running → stops [OverlayService] and updates DataStore.
 *  • If the overlay is stopped → starts [OverlayService] (requires
 *    SYSTEM_ALERT_WINDOW permission; the tile checks before starting).
 */
@AndroidEntryPoint
class ShadowFixTileService : TileService() {

    @Inject lateinit var settingsDataStore: SettingsDataStore

    private val tileScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── Tile lifecycle ─────────────────────────────────────────────────────────

    override fun onStartListening() {
        super.onStartListening()
        // Sync tile state with the persisted master-enabled flag.
        tileScope.launch {
            val enabled = settingsDataStore.masterEnabled.first()
            updateTile(enabled)
        }
    }

    override fun onStopListening() {
        super.onStopListening()
        // No cleanup needed; tileScope remains alive for the service lifetime.
    }

    override fun onDestroy() {
        tileScope.cancel()
        super.onDestroy()
    }

    // ── Click handling ────────────────────────────────────────────────────────

    override fun onClick() {
        super.onClick()
        tileScope.launch {
            val currentlyEnabled = settingsDataStore.masterEnabled.first()
            val newState = !currentlyEnabled
            settingsDataStore.setMasterEnabled(newState)
            updateTile(newState)

            if (newState) {
                startOverlayService()
            } else {
                stopOverlayService()
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun updateTile(enabled: Boolean) {
        qsTile?.apply {
            state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        startForegroundService(intent)
    }

    private fun stopOverlayService() {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_STOP
        }
        startService(intent)
    }
}
