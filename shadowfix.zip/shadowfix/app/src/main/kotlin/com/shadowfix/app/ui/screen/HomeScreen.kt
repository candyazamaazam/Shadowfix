package com.shadowfix.app.ui.screen

import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shadowfix.app.ui.components.ProfileCard
import com.shadowfix.app.ui.components.SliderCard
import com.shadowfix.app.viewmodel.HomeViewModel

/**
 * Home Screen — the primary control surface for ShadowFix.
 *
 * Layout (scrollable):
 *  1. Permission warning banner (shown if SYSTEM_ALERT_WINDOW not granted).
 *  2. Master enable card (large switch + status text).
 *  3. Active profile selector (horizontal scroll of [ProfileCard]s).
 *  4. Enhancement sliders (6 × [SliderCard]).
 *  5. Action row: Reset | Save Profile.
 */
@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val context  = LocalContext.current

    val snackbarHostState = remember { SnackbarHostState() }
    var showSaveDialog by rememberSaveable { mutableStateOf(false) }
    var saveProfileName by rememberSaveable { mutableStateOf("") }

    val hasOverlayPermission = remember { viewModel.hasOverlayPermission() }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = contentPadding.calculateTopPadding() + 8.dp,
                bottom = contentPadding.calculateBottomPadding() + 8.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ── Permission warning ────────────────────────────────────────────
            if (!hasOverlayPermission) {
                item {
                    PermissionWarningCard(
                        onGrantClick = { viewModel.openOverlayPermissionSettings() }
                    )
                }
            }

            // ── App title ─────────────────────────────────────────────────────
            item {
                Text(
                    text = "ShadowFix",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
                Text(
                    text = "AMOLED shadow enhancement",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // ── Master switch ─────────────────────────────────────────────────
            item {
                MasterSwitchCard(
                    enabled = uiState.masterEnabled,
                    onToggle = { viewModel.setMasterEnabled(it) },
                    hasPermission = hasOverlayPermission
                )
            }

            // ── Profile selector ──────────────────────────────────────────────
            item {
                Text(
                    text = "Profile",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(profiles, key = { it.id }) { profile ->
                        ProfileCard(
                            profile  = profile,
                            isActive = profile.id == uiState.activeProfileId,
                            onClick  = { viewModel.setActiveProfile(profile) },
                            modifier = Modifier.fillParentMaxWidth(0.75f)
                        )
                    }
                }
            }

            // ── Sliders ───────────────────────────────────────────────────────
            item {
                Text(
                    text = "Enhancement",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )
            }

            item {
                SliderCard(
                    title       = "Near Black Recovery",
                    description = "Lifts shadow values that collapse to pure black on AMOLED.",
                    value       = uiState.nearBlack,
                    onValueChange = viewModel::setNearBlack,
                    enabled     = uiState.masterEnabled
                )
            }
            item {
                SliderCard(
                    title       = "Gamma",
                    description = "Brightens mid-tones without clipping highlights.",
                    value       = uiState.gamma,
                    onValueChange = viewModel::setGamma,
                    enabled     = uiState.masterEnabled
                )
            }
            item {
                SliderCard(
                    title       = "Shadow Boost",
                    description = "Amplifies the lower luminance band (0–40% brightness).",
                    value       = uiState.shadowBoost,
                    onValueChange = viewModel::setShadowBoost,
                    enabled     = uiState.masterEnabled
                )
            }
            item {
                SliderCard(
                    title       = "Contrast",
                    description = "Overall contrast scale. Centre = neutral.",
                    value       = uiState.contrast,
                    onValueChange = viewModel::setContrast,
                    enabled     = uiState.masterEnabled
                )
            }
            item {
                SliderCard(
                    title       = "Black Level",
                    description = "Raises the absolute minimum output level above pure black.",
                    value       = uiState.blackLevel,
                    onValueChange = viewModel::setBlackLevel,
                    enabled     = uiState.masterEnabled
                )
            }
            item {
                SliderCard(
                    title       = "Strength",
                    description = "Master blend: 0 = no overlay, 100 = full effect.",
                    value       = uiState.strength,
                    onValueChange = viewModel::setStrength,
                    enabled     = uiState.masterEnabled
                )
            }

            // ── Action row ────────────────────────────────────────────────────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.resetToDefaults() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Filled.RestartAlt,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text("Reset")
                    }
                    Button(
                        onClick = {
                            saveProfileName = ""
                            showSaveDialog = true
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Filled.Save,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text("Save Profile")
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // ── Snackbar ──────────────────────────────────────────────────────────
        SnackbarHost(
            hostState = snackbarHostState,
            modifier  = Modifier.align(Alignment.BottomCenter)
        )
    }

    // ── Save profile dialog ───────────────────────────────────────────────────
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Profile") },
            text = {
                OutlinedTextField(
                    value = saveProfileName,
                    onValueChange = { saveProfileName = it },
                    label = { Text("Profile name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (saveProfileName.isNotBlank()) {
                            viewModel.saveCurrentAsProfile(saveProfileName.trim())
                            showSaveDialog = false
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ── Sub-composables ────────────────────────────────────────────────────────────

@Composable
private fun MasterSwitchCard(
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
    hasPermission: Boolean
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.Power,
                        contentDescription = null,
                        tint = if (enabled) MaterialTheme.colorScheme.primary
                               else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(
                        text = "Enhancement",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = if (enabled) "Active — overlay running"
                           else "Inactive — tap to enable",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (enabled) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Switch(
                checked = enabled,
                onCheckedChange = { if (hasPermission) onToggle(it) },
                enabled = hasPermission
            )
        }
    }
}

@Composable
private fun PermissionWarningCard(onGrantClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        ),
        shape = MaterialTheme.shapes.large
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Permission required",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Text(
                    text = "\"Display over other apps\" permission is needed for the overlay.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            TextButton(onClick = onGrantClick) {
                Text("Grant")
            }
        }
    }
}
