package com.shadowfix.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shadowfix.app.ui.screen.HomeScreen
import com.shadowfix.app.ui.screen.ProfilesScreen
import com.shadowfix.app.ui.screen.SettingsScreen

// ── Route constants ────────────────────────────────────────────────────────────

sealed class Screen(val route: String, val label: String) {
    data object Home     : Screen("home",     "Home")
    data object Profiles : Screen("profiles", "Profiles")
    data object Settings : Screen("settings", "Settings")
}

private val bottomNavItems = listOf(
    Triple(Screen.Home,     Icons.Filled.Home,     "Home"),
    Triple(Screen.Profiles, Icons.Filled.Style,    "Profiles"),
    Triple(Screen.Settings, Icons.Filled.Settings, "Settings")
)

/**
 * Root navigation graph for ShadowFix.
 *
 * Uses a [Scaffold] with a [NavigationBar] for bottom navigation between the
 * three top-level screens.  Slide animations are used for screen transitions to
 * maintain a 60 fps feel on the CMF Phone 1's 120 Hz panel.
 */
@Composable
fun ShadowFixNavGraph(
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    Scaffold(
        bottomBar = {
            NavigationBar {
                bottomNavItems.forEach { (screen, icon, label) ->
                    NavigationBarItem(
                        icon     = { Icon(icon, contentDescription = label) },
                        label    = { Text(label) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick  = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState    = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = Screen.Home.route,
            enterTransition  = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(250)
                )
            },
            exitTransition  = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(250)
                )
            },
            popEnterTransition = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(250)
                )
            },
            popExitTransition  = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(250)
                )
            }
        ) {
            composable(Screen.Home.route)     { HomeScreen(contentPadding = innerPadding) }
            composable(Screen.Profiles.route) { ProfilesScreen(contentPadding = innerPadding) }
            composable(Screen.Settings.route) { SettingsScreen(contentPadding = innerPadding) }
        }
    }
}
