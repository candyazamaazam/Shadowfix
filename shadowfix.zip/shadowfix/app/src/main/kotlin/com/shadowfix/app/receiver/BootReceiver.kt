package com.shadowfix.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.shadowfix.app.data.datastore.SettingsDataStore
import com.shadowfix.app.service.OverlayService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * BootReceiver — restarts the overlay service after the device reboots.
 *
 * Responds to:
 *  • [Intent.ACTION_BOOT_COMPLETED]       — device boot.
 *  • [Intent.ACTION_MY_PACKAGE_REPLACED]  — app update (re-start after OTA).
 *
 * The receiver checks [SettingsDataStore.autoStartOnBoot] before starting;
 * if the user has not enabled auto-start, the service is NOT started.
 *
 * [SettingsDataStore.masterEnabled] is also checked: if the user had the
 * overlay disabled before the reboot, we honour that preference.
 */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject lateinit var settingsDataStore: SettingsDataStore

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        // Use goAsync() so we can safely read DataStore on a coroutine without
        // the receiver being killed before the async work completes.
        val pendingResult = goAsync()
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

        scope.launch {
            try {
                val autoStart = settingsDataStore.autoStartOnBoot.first()
                val masterEnabled = settingsDataStore.masterEnabled.first()

                if (autoStart && masterEnabled) {
                    val serviceIntent = Intent(context, OverlayService::class.java)
                    context.startForegroundService(serviceIntent)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
