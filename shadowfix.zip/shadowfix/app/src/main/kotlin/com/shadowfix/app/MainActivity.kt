package com.shadowfix.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.shadowfix.app.data.datastore.SettingsDataStore
import com.shadowfix.app.ui.navigation.ShadowFixNavGraph
import com.shadowfix.app.ui.theme.ShadowFixTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Single-activity entry point for ShadowFix.
 *
 * All navigation is handled by Compose Navigation inside [ShadowFixNavGraph].
 * Edge-to-edge display is enabled so the overlay preview can demonstrate
 * full-screen behaviour without system-bar chrome interfering.
 *
 * [SettingsDataStore] is injected here so the root [ShadowFixTheme] can react
 * to the user's dark-mode and dynamic-colour preferences in real time.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var settingsDataStore: SettingsDataStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ShadowFixTheme(settingsDataStore = settingsDataStore) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ShadowFixNavGraph()
                }
            }
        }
    }
}
