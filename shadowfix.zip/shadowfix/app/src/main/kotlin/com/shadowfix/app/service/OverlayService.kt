package com.shadowfix.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.shadowfix.app.MainActivity
import com.shadowfix.app.R
import com.shadowfix.app.ShadowFixApplication.Companion.CHANNEL_OVERLAY
import com.shadowfix.app.ShadowFixApplication.Companion.NOTIFICATION_OVERLAY_ID
import com.shadowfix.app.data.datastore.SettingsDataStore
import com.shadowfix.app.data.model.Profile
import com.shadowfix.app.data.repository.ProfileRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.pow

/**
 * OverlayService — the core enhancement engine for ShadowFix.
 *
 * ── What this does ──────────────────────────────────────────────────────────
 * Draws a single full-screen, hardware-accelerated [View] over all other apps
 * using [WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY].
 *
 * The view has no visible content of its own; its entire purpose is to carry
 * a [Paint] with a custom [ColorMatrix] that Android's Render Thread applies
 * to every pixel it composites on top of.  This is the standard non-root
 * technique for system-wide colour correction on Android.
 *
 * ── Technical limitations ────────────────────────────────────────────────────
 * Android's compositor applies the overlay AFTER the OLED panel maps pixel
 * values, so this cannot undo hardware-level gamma or the OLED driver's
 * native black-crush curve.  What it CAN do is:
 *
 *  1. Lift near-black colours before they reach the panel (nearBlack, blackLevel).
 *  2. Apply a software gamma curve that brightens mid-to-shadow tones (gamma).
 *  3. Amplify the shadow band (0–40 % luminance) with a targeted gain (shadowBoost).
 *  4. Adjust overall perceived contrast (contrast).
 *  5. Blend all of the above proportionally to a master strength value (strength).
 *
 * The ColorMatrix approach is zero-CPU-cost per frame once set: the GPU handles
 * colour-matrix math natively in the GLES blending stage.
 *
 * ── Battery impact ──────────────────────────────────────────────────────────
 * The overlay view is fully transparent (alpha ~0.01) and hardware-layered.
 * It does NOT redraw on every frame; the matrix is only recomputed when the
 * user changes a slider.  Quiescent CPU cost is < 0.1 % in typical use.
 *
 * ── Window type ──────────────────────────────────────────────────────────────
 * TYPE_APPLICATION_OVERLAY is the highest window type available to third-party
 * apps without root.  It sits above regular app windows and below system UI
 * (status bar, nav bar).  The SYSTEM_ALERT_WINDOW permission must be granted
 * by the user before this service is started.
 */
@AndroidEntryPoint
class OverlayService : Service() {

    @Inject lateinit var settingsDataStore: SettingsDataStore
    @Inject lateinit var profileRepository: ProfileRepository

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WindowManager::class.java)
        startForeground(NOTIFICATION_OVERLAY_ID, buildNotification())
        addOverlayView()
        observeSettings()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlayView()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── Overlay view ──────────────────────────────────────────────────────────

    private fun addOverlayView() {
        if (overlayView != null) return

        val view = View(this).apply {
            // The view itself renders nothing; it only carries the Paint/ColorMatrix.
            // A near-zero alpha (0.01f) is required — a fully transparent view
            // is optimised away by the compositor and the layer has no effect.
            alpha = 0.01f
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_TOUCHABLE + NOT_FOCUSABLE: the overlay never consumes input events.
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager.addView(view, params)
            overlayView = view
        } catch (e: Exception) {
            // Window manager may reject the view if the permission was revoked mid-session.
            stopSelf()
        }
    }

    private fun removeOverlayView() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) { /* already detached */ }
            overlayView = null
        }
    }

    // ── Settings observation ──────────────────────────────────────────────────

    /**
     * Combines all relevant settings flows and recomputes the [ColorMatrix]
     * whenever any value changes.  Running on the Main dispatcher keeps view
     * operations on the UI thread without extra posting.
     */
    private fun observeSettings() {
        serviceScope.launch {
            combine(
                settingsDataStore.nearBlack,
                settingsDataStore.gamma,
                settingsDataStore.shadowBoost,
                settingsDataStore.contrast,
                settingsDataStore.blackLevel,
                settingsDataStore.strength
            ) { values ->
                OverlayParams(
                    nearBlack = values[0],
                    gamma = values[1],
                    shadowBoost = values[2],
                    contrast = values[3],
                    blackLevel = values[4],
                    strength = values[5]
                )
            }.collect { params ->
                applyColorMatrix(params)
            }
        }
    }

    // ── ColorMatrix computation ───────────────────────────────────────────────

    /**
     * Builds and applies a [ColorMatrix] derived from the current [OverlayParams].
     *
     * The matrix pipeline is:
     *
     *  1. Black-point lift: adds [blackLevel] to the absolute minimum output so
     *     crushed blacks become very-dark-grey instead of pure black.
     *
     *  2. Near-black recovery: scales the low end of the luminance range so that
     *     colours that would map to ≤ ~8 % brightness get a proportional lift.
     *     This is the primary mitigation for AMOLED black crush.
     *
     *  3. Shadow boost: an additional per-channel gain applied via the translation
     *     component (offset) that primarily affects the shadow region.
     *
     *  4. Gamma correction: approximated with a linear piecewise lift derived from
     *     the target gamma exponent.  A full per-pixel LUT would require a
     *     ShaderEffect (API 33+) which some devices don't support.  The linear
     *     approximation is good enough for AMOLED shadow recovery.
     *
     *  5. Contrast: scales the matrix diagonal above/below 1.0 with a complementary
     *     translation to keep mid-grey anchored.
     *
     *  6. Strength blend: lerps the full matrix towards the identity matrix so the
     *     master strength slider acts as a global mix control.
     *
     * All arithmetic uses 0–1 normalised float space (ColorMatrix scale = 1.0 = full).
     */
    private fun applyColorMatrix(p: OverlayParams) {
        val view = overlayView ?: return

        // ── Step 1: black-point lift ─────────────────────────────────────────
        // Add a constant offset to R, G, B (not alpha).
        val blackLift = p.blackLevel * 255f   // Convert to 0-255 space

        // ── Step 2: near-black recovery gain ────────────────────────────────
        // Slightly scale up R/G/B so near-black values are raised.
        // E.g. nearBlack=0.35 → scale=1.35 on diagonal
        val nearBlackGain = 1f + (p.nearBlack * 0.5f)   // max +50 % gain

        // ── Step 3: shadow boost offset ──────────────────────────────────────
        // An additional fixed offset that predominantly helps shadows.
        val shadowOffset = p.shadowBoost * 20f   // max +20 in 0-255 space

        // ── Step 4: gamma lift (linearised approximation) ───────────────────
        // Target gamma exponent: neutral=1.0, max lift: gamma=0.5
        // We approximate the curve with a scale+translate that matches the
        // gamma power function at luminance=0.18 (the photographic mid-grey).
        val targetGamma = 1.0f - (p.gamma * 0.5f)   // 1.0 → 0.5
        val gammaGain = if (targetGamma < 1.0f) {
            // At mid-grey (0.18) the lift is: 0.18^targetGamma / 0.18^1.0
            (0.18f.pow(targetGamma) / 0.18f)
        } else 1.0f

        // ── Step 5: contrast ─────────────────────────────────────────────────
        // contrast=0.5 → scale=1.0 (neutral)
        // contrast=1.0 → scale=1.4 (high contrast)
        // contrast=0.0 → scale=0.6 (low contrast)
        val contrastScale = 0.6f + (p.contrast * 0.8f)   // range 0.6–1.4
        // Translate to keep mid-grey (127.5 in 0-255) constant.
        val contrastTranslate = 127.5f * (1f - contrastScale)

        // ── Combine into a single 4×5 ColorMatrix ───────────────────────────
        // ColorMatrix layout (row-major, 4 rows × 5 cols):
        //   [ rR rG rB rA rT ]
        //   [ gR gG gB gA gT ]
        //   [ bR bG bB bA bT ]
        //   [ aR aG aB aA aT ]
        // Where T = translation (added after scaling).

        val combinedScale = nearBlackGain * gammaGain * contrastScale
        val combinedTranslate = blackLift + shadowOffset + contrastTranslate

        // Build the "effect" matrix
        val effectMatrix = FloatArray(20) { 0f }.also { m ->
            // Red channel
            m[0] = combinedScale;   m[4] = combinedTranslate
            // Green channel
            m[6] = combinedScale;   m[9] = combinedTranslate
            // Blue channel
            m[12] = combinedScale;  m[14] = combinedTranslate
            // Alpha passthrough
            m[18] = 1f
        }

        // Identity matrix for blending
        val identity = FloatArray(20) { 0f }.also { m ->
            m[0] = 1f; m[6] = 1f; m[12] = 1f; m[18] = 1f
        }

        // ── Step 6: blend with identity by strength ──────────────────────────
        val s = p.strength
        val blended = FloatArray(20) { i ->
            identity[i] + (effectMatrix[i] - identity[i]) * s
        }

        val colorMatrix = ColorMatrix(blended)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }

        view.post {
            view.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_OVERLAY)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notification_overlay_title))
            .setContentText(getString(R.string.notification_overlay_text))
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.notification_action_stop), stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    // ── Companion ─────────────────────────────────────────────────────────────

    companion object {
        const val ACTION_STOP = "com.shadowfix.app.STOP_OVERLAY"
    }

    /** Immutable snapshot of overlay parameters passed to the matrix builder. */
    private data class OverlayParams(
        val nearBlack: Float,
        val gamma: Float,
        val shadowBoost: Float,
        val contrast: Float,
        val blackLevel: Float,
        val strength: Float
    )
}
