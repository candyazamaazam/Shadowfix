package com.shadowfix.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

/**
 * ShadowFix Application class.
 *
 * Serves as the Hilt component host and performs one-time app-wide
 * initialisation tasks such as creating notification channels.
 */
@HiltAndroidApp
class ShadowFixApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    /**
     * Creates all notification channels used by the app.
     * Channels must be registered before any notification is posted.
     */
    private fun createNotificationChannels() {
        val manager = getSystemService(NotificationManager::class.java)

        // ── Overlay service channel ──────────────────────────────────────────
        // Shown while the enhancement overlay is active. Kept at LOW importance
        // to minimise intrusion while still satisfying foreground-service rules.
        val overlayChannel = NotificationChannel(
            CHANNEL_OVERLAY,
            getString(R.string.channel_overlay_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.channel_overlay_description)
            setShowBadge(false)
        }

        // ── General / alert channel ──────────────────────────────────────────
        // Used for one-off informational messages (e.g. permission prompts).
        val generalChannel = NotificationChannel(
            CHANNEL_GENERAL,
            getString(R.string.channel_general_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = getString(R.string.channel_general_description)
        }

        manager.createNotificationChannels(listOf(overlayChannel, generalChannel))
    }

    companion object {
        /** Notification channel for the persistent overlay foreground service. */
        const val CHANNEL_OVERLAY = "shadowfix_overlay"

        /** Notification channel for general informational alerts. */
        const val CHANNEL_GENERAL = "shadowfix_general"

        /** ID for the overlay service foreground notification. */
        const val NOTIFICATION_OVERLAY_ID = 1001
    }
}
