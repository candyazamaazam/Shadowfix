package com.shadowfix.app.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowfix.app.data.datastore.SettingsDataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * SettingsViewModel — drives the Settings screen.
 *
 * Exposes a single [SettingsUiState] and individual setter functions
 * for each preference toggle.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsDataStore: SettingsDataStore
) : ViewModel() {

    val uiState: StateFlow<SettingsUiState> = combine(
        settingsDataStore.autoStartOnBoot,
        settingsDataStore.dynamicColors,
        settingsDataStore.darkMode,
        settingsDataStore.perAppProfilesEnabled
    ) { autoStart, dynamicColors, darkMode, perApp ->
        SettingsUiState(
            autoStartOnBoot       = autoStart,
            dynamicColors         = dynamicColors,
            darkMode              = darkMode,
            perAppProfilesEnabled = perApp
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState()
    )

    // ── Setters ───────────────────────────────────────────────────────────────

    fun setAutoStartOnBoot(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setAutoStartOnBoot(enabled) }
    }

    fun setDynamicColors(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setDynamicColors(enabled) }
    }

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setDarkMode(enabled) }
    }

    fun setPerAppProfilesEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setPerAppProfilesEnabled(enabled) }
    }

    // ── System intents ────────────────────────────────────────────────────────

    /**
     * Opens the system Battery Optimisation settings so the user can
     * exempt ShadowFix — required to keep the overlay service alive
     * during aggressive Doze cycles.
     */
    fun openBatteryOptimisationSettings() {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            // Fallback: open general battery settings
            context.startActivity(
                Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /**
     * Opens the Accessibility Settings page so the user can enable
     * [com.shadowfix.app.service.ShadowFixAccessibilityService].
     */
    fun openAccessibilitySettings() {
        context.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /**
     * Returns true if ShadowFix is exempt from battery optimisation.
     */
    fun isBatteryOptimisationIgnored(): Boolean {
        val pm = context.getSystemService(PowerManager::class.java)
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }
}

data class SettingsUiState(
    val autoStartOnBoot: Boolean       = false,
    val dynamicColors: Boolean         = true,
    val darkMode: Boolean              = true,
    val perAppProfilesEnabled: Boolean = false
)
