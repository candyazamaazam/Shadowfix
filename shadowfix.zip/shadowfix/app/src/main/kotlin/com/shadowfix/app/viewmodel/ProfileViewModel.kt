package com.shadowfix.app.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowfix.app.data.model.Profile
import com.shadowfix.app.data.repository.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ProfileViewModel — drives the Profiles management screen.
 *
 * Responsibilities:
 *  • Expose the full profile list to the UI.
 *  • Handle create, rename, delete, and app-mapping edits.
 *  • Orchestrate JSON import/export via the SAF content URI.
 */
@HiltViewModel
class ProfileViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val profileRepository: ProfileRepository
) : ViewModel() {

    /** Observed profile list. */
    val profiles: StateFlow<List<Profile>> = profileRepository.profiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** One-shot event emitted when an export or import operation finishes. */
    private val _operationResult = MutableStateFlow<OperationResult?>(null)
    val operationResult: StateFlow<OperationResult?> = _operationResult.asStateFlow()

    // ── CRUD ──────────────────────────────────────────────────────────────────

    fun createProfile(name: String) {
        viewModelScope.launch {
            val profile = profileRepository.createNew(name)
            profileRepository.save(profile)
        }
    }

    fun saveProfile(profile: Profile) {
        viewModelScope.launch {
            profileRepository.save(profile)
        }
    }

    fun deleteProfile(id: String) {
        viewModelScope.launch {
            val deleted = profileRepository.delete(id)
            if (!deleted) {
                _operationResult.value = OperationResult.Error("Cannot delete a built-in preset profile.")
            }
        }
    }

    /** Adds or removes [packageName] from the per-app mapping of [profileId]. */
    fun toggleAppMapping(profileId: String, packageName: String) {
        viewModelScope.launch {
            val profile = profileRepository.getById(profileId) ?: return@launch
            val updated = if (packageName in profile.appPackages) {
                profile.copy(appPackages = profile.appPackages - packageName)
            } else {
                profile.copy(appPackages = profile.appPackages + packageName)
            }
            profileRepository.save(updated)
        }
    }

    // ── Export ────────────────────────────────────────────────────────────────

    /**
     * Writes the current profile list as JSON to the [uri] selected by the user
     * via the Storage Access Framework document picker.
     */
    fun exportProfiles(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = profileRepository.exportToJson()
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(json.toByteArray(Charsets.UTF_8))
                }
                _operationResult.value = OperationResult.Success("Profiles exported successfully.")
            } catch (e: Exception) {
                _operationResult.value = OperationResult.Error("Export failed: ${e.message}")
            }
        }
    }

    // ── Import ────────────────────────────────────────────────────────────────

    /**
     * Reads a JSON profile file from the [uri] selected by the user
     * and merges the contained profiles into the repository.
     */
    fun importProfiles(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader(Charsets.UTF_8).readText()
                } ?: throw IllegalStateException("Could not open file.")
                profileRepository.importFromJson(json)
                _operationResult.value = OperationResult.Success("Profiles imported successfully.")
            } catch (e: Exception) {
                _operationResult.value = OperationResult.Error("Import failed: ${e.message}")
            }
        }
    }

    /** Clears the one-shot operation result after the UI has consumed it. */
    fun clearOperationResult() {
        _operationResult.value = null
    }
}

sealed interface OperationResult {
    data class Success(val message: String) : OperationResult
    data class Error(val message: String) : OperationResult
}
