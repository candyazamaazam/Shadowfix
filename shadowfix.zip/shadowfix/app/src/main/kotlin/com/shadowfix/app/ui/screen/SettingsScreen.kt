package com.shadowfix.app.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shadowfix.app.viewmodel.SettingsViewModel

/**
 * Settings Screen — controls for app-wide behaviour and system integration.
 */
@Composable
fun SettingsScreen(
    contentPadding: PaddingValues,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 8.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }

        // ── Behaviour ─────────────────────────────────────────────────────────
        item {
            SettingsSectionHeader("Behaviour")
        }
        item {
            ToggleSettingItem(
                icon        = Icons.Filled.PlayArrow,
                title       = "Auto-start on boot",
                description = "Restart the overlay automatically after device reboot.",
                checked     = uiState.autoStartOnBoot,
                onToggle    = viewModel::setAutoStartOnBoot
            )
        }
        item {
            ToggleSettingItem(
                icon        = Icons.Filled.PhoneAndroid,
                title       = "Per-app profiles",
                description = "Automatically switch profiles when you open a mapped app.\nRequires Accessibility Service.",
                checked     = uiState.perAppProfilesEnabled,
                onToggle    = viewModel::setPerAppProfilesEnabled
            )
        }

        // ── Appearance ────────────────────────────────────────────────────────
        item {
            SettingsSectionHeader("Appearance")
        }
        item {
            ToggleSettingItem(
                icon        = Icons.Filled.Palette,
                title       = "Material You colours",
                description = "Use dynamic colours extracted from your wallpaper (Android 12+).",
                checked     = uiState.dynamicColors,
                onToggle    = viewModel::setDynamicColors
            )
        }
        item {
            ToggleSettingItem(
                icon        = Icons.Filled.DarkMode,
                title       = "Dark mode",
                description = "Force dark theme regardless of system setting.",
                checked     = uiState.darkMode,
                onToggle    = viewModel::setDarkMode
            )
        }

        // ── System ────────────────────────────────────────────────────────────
        item {
            SettingsSectionHeader("System")
        }
        item {
            ActionSettingItem(
                icon        = Icons.Filled.BatteryFull,
                title       = "Battery optimisation",
                description = "Exempt ShadowFix from Doze to keep the overlay alive.",
                actionLabel = "Configure",
                onAction    = viewModel::openBatteryOptimisationSettings
            )
        }
        item {
            ActionSettingItem(
                icon        = Icons.Filled.Accessibility,
                title       = "Accessibility Service",
                description = "Enable to allow per-app automatic profile switching.\nShadowFix only observes window changes — it never reads screen content.",
                actionLabel = "Open Settings",
                onAction    = viewModel::openAccessibilitySettings
            )
        }

        // ── About ─────────────────────────────────────────────────────────────
        item {
            SettingsSectionHeader("About")
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = MaterialTheme.shapes.large
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text  = "ShadowFix 1.0.0",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text  = "AMOLED shadow enhancement for CMF Phone 1 / Nothing OS 4.x",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text  = "No root required · Offline only · No ads",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text  = "Technical note: ShadowFix applies a hardware-accelerated ColorMatrix " +
                                "overlay via TYPE_APPLICATION_OVERLAY. It cannot modify the OLED panel " +
                                "hardware pipeline or display driver — only software-layer compensation " +
                                "is possible without root.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}

// ── Sub-composables ────────────────────────────────────────────────────────────

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text  = title.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
    )
}

@Composable
private fun ToggleSettingItem(
    icon: ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = MaterialTheme.shapes.large
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text  = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = checked, onCheckedChange = onToggle)
        }
    }
}

@Composable
private fun ActionSettingItem(
    icon: ImageVector,
    title: String,
    description: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = MaterialTheme.shapes.large
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text  = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledTonalButton(onClick = onAction) {
                Text(actionLabel)
            }
        }
    }
}
