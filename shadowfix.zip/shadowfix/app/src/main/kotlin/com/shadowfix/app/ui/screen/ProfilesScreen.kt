package com.shadowfix.app.ui.screen

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shadowfix.app.data.model.Profile
import com.shadowfix.app.ui.components.ProfileCard
import com.shadowfix.app.viewmodel.OperationResult
import com.shadowfix.app.viewmodel.ProfileViewModel

/**
 * Profiles Screen — lets the user browse, create, delete, and import/export profiles.
 *
 * Built-in preset profiles (id starts with "preset_") show a delete button that
 * is hidden because [ProfileViewModel.deleteProfile] will reject them.
 */
@Composable
fun ProfilesScreen(
    contentPadding: PaddingValues,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val operationResult by viewModel.operationResult.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    var showCreateDialog by rememberSaveable { mutableStateOf(false) }
    var newProfileName   by rememberSaveable { mutableStateOf("") }
    var confirmDeleteId  by rememberSaveable { mutableStateOf<String?>(null) }

    // ── SAF launchers ─────────────────────────────────────────────────────────

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        uri?.let { viewModel.exportProfiles(it) }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.importProfiles(it) }
    }

    // ── Show snackbar on operation result ─────────────────────────────────────

    LaunchedEffect(operationResult) {
        operationResult?.let { result ->
            val msg = when (result) {
                is OperationResult.Success -> result.message
                is OperationResult.Error   -> result.message
            }
            snackbarHostState.showSnackbar(msg)
            viewModel.clearOperationResult()
        }
    }

    Scaffold(
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                newProfileName = ""
                showCreateDialog = true
            }) {
                Icon(Icons.Filled.Add, contentDescription = "Create profile")
            }
        }
    ) { scaffoldPadding ->

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = maxOf(
                    contentPadding.calculateTopPadding(),
                    scaffoldPadding.calculateTopPadding()
                ) + 8.dp,
                bottom = maxOf(
                    contentPadding.calculateBottomPadding(),
                    scaffoldPadding.calculateBottomPadding()
                ) + 88.dp    // space for FAB
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    text = "Profiles",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            // ── Import / Export row ───────────────────────────────────────────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { importLauncher.launch(arrayOf("application/json")) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Filled.Download,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text("Import")
                    }
                    FilledTonalButton(
                        onClick = { exportLauncher.launch("shadowfix_profiles.json") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Filled.Upload,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text("Export")
                    }
                }
            }

            // ── Profile list ──────────────────────────────────────────────────
            items(profiles, key = { it.id }) { profile ->
                ProfileListItem(
                    profile       = profile,
                    onDeleteClick = {
                        if (!profile.id.startsWith("preset_")) {
                            confirmDeleteId = profile.id
                        }
                    }
                )
            }
        }
    }

    // ── Create profile dialog ─────────────────────────────────────────────────
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("New Profile") },
            text = {
                OutlinedTextField(
                    value = newProfileName,
                    onValueChange = { newProfileName = it },
                    label = { Text("Profile name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newProfileName.isNotBlank()) {
                        viewModel.createProfile(newProfileName.trim())
                        showCreateDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    // ── Delete confirmation dialog ────────────────────────────────────────────
    if (confirmDeleteId != null) {
        AlertDialog(
            onDismissRequest = { confirmDeleteId = null },
            title = { Text("Delete Profile") },
            text  = { Text("This profile will be permanently removed.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirmDeleteId?.let { viewModel.deleteProfile(it) }
                        confirmDeleteId = null
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteId = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ProfileListItem(
    profile: Profile,
    onDeleteClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProfileCard(
            profile  = profile,
            isActive = false,
            onClick  = {},
            modifier = Modifier.weight(1f)
        )
        if (!profile.id.startsWith("preset_")) {
            IconButton(onClick = onDeleteClick) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "Delete ${profile.name}",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
