# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in the Android SDK proguard-defaults.txt file.

# Keep data model classes (used with Gson for profile import/export)
-keep class com.shadowfix.app.data.model.** { *; }

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }

# Keep DataStore classes
-keep class androidx.datastore.** { *; }

# Keep Gson serialization
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }

# Keep service and receiver names (referenced in manifest)
-keep class com.shadowfix.app.service.** { *; }
-keep class com.shadowfix.app.receiver.** { *; }
