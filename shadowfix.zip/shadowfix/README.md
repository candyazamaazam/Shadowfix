# ShadowFix

**AMOLED shadow enhancement for CMF Phone 1 / Nothing OS 4.x**

ShadowFix is a production-quality Android application that reduces the visual effects of AMOLED black crush using every API legally available to a third-party, non-rooted application.

---

## How it works

ShadowFix draws a full-screen, **hardware-accelerated** overlay using `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY` and applies a custom `ColorMatrix` via Android's Render Thread. This is the only non-root technique available for system-wide per-pixel colour correction on Android.

### What it can do

| Effect | Mechanism |
|--------|-----------|
| Near-black recovery | ColorMatrix diagonal gain — lifts shadow values before they reach the panel |
| Gamma correction | Linearised mid-grey anchored approximation of γ < 1.0 |
| Shadow boost | Per-channel translation offset applied to the low luminance band |
| Contrast control | Scale + translate with mid-grey anchor (127.5) |
| Black-point lift | Constant offset added to R/G/B channels |
| Master strength | Identity lerp — blends all effects from 0 % to 100 % |

### What it cannot do (honest limitations)

> Android's compositor applies the overlay **after** the OLED panel's hardware gamma and driver-level black-crush mapping. ShadowFix cannot undo hardware-level display pipeline decisions. The improvements are real but are applied in software, not at the display driver level.

---

## Setup

### Prerequisites
- Android Studio Ladybug (2024.2) or later
- JDK 17+
- Android 9+ device (minSdk 29)
- Target: Android 16 / SDK 36

### Build

```bash
# Debug APK
./gradlew assembleDebug

# Release APK (requires signing config)
./gradlew assembleRelease
```

### Required permissions

| Permission | Why |
|-----------|-----|
| `SYSTEM_ALERT_WINDOW` | Draw overlay on top of other apps (user must grant manually) |
| `FOREGROUND_SERVICE` | Keep overlay service alive |
| `POST_NOTIFICATIONS` | Persistent service control notification |
| `RECEIVE_BOOT_COMPLETED` | Auto-start on boot (optional, user-controlled) |

### Optional: Accessibility Service

Enable **ShadowFix Per-App Profiles** in **Settings → Accessibility** to allow automatic profile switching when you open mapped applications. This service **only** observes window-state change events and never reads screen content.

---

## Architecture

```
app/
├── data/
│   ├── datastore/     # SettingsDataStore — Jetpack DataStore (Preferences)
│   ├── model/         # Profile, ProfileType, ProfileDefaults
│   └── repository/    # ProfileRepository — JSON file persistence + Gson
├── di/                # Hilt AppModule
├── receiver/          # BootReceiver
├── service/
│   ├── OverlayService                  # Core ColorMatrix overlay engine
│   ├── ShadowFixAccessibilityService   # Per-app profile switcher
│   └── ShadowFixTileService            # Quick Settings tile
├── ui/
│   ├── components/    # SliderCard, ProfileCard
│   ├── navigation/    # ShadowFixNavGraph
│   ├── screen/        # HomeScreen, ProfilesScreen, SettingsScreen
│   └── theme/         # Color, Type, Theme (Material 3)
└── viewmodel/         # HomeViewModel, ProfileViewModel, SettingsViewModel
```

**Tech stack:** Kotlin · Jetpack Compose · Material 3 · Hilt · DataStore · Coroutines · StateFlow · Compose Navigation

---

## Performance targets

| Metric | Target | Technique |
|--------|--------|-----------|
| CPU (overlay quiescent) | < 0.1 % | GPU-side ColorMatrix, no per-frame CPU work |
| Battery | < 2 % per hour | No wake locks, hardware layer, minimal coroutine activity |
| Memory | < 100 MB | No bitmap allocations; overlay view carries only a Paint |
| Frame rate | 60–120 fps | Hardware-accelerated layer, no view invalidation |

---

## Profiles

Six built-in presets (read-only):

| Profile | Best for | Key characteristic |
|---------|----------|--------------------|
| Movie | Dark cinema content | Strong near-black recovery |
| Gaming | Low-light gameplay | Shadow boost + higher contrast |
| Reading | Long reading sessions | Minimal overlay, gentle gamma |
| Night | Very dark environments | Maximum lift across all parameters |
| Outdoor | Bright sunlight | Reduced effect, slight contrast boost |
| Custom | User-defined | Starts at balanced defaults |

Custom profiles can be created, exported (JSON), and imported.

---

## Licence

Apache 2.0 — see [LICENSE](LICENSE)
